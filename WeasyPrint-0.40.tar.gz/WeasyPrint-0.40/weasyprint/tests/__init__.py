# coding: utf-8
"""
    weasyprint.tests
    ----------------

    The Weasyprint test suite.

    :copyright: Copyright 2011-2014 Simon Sapin and contributors, see AUTHORS.
    :license: BSD, see LICENSE for details.

"""

from __future__ import division, unicode_literals
